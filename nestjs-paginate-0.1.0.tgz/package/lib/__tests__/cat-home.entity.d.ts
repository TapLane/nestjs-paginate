import { CatHomePillowEntity } from './cat-home-pillow.entity';
import { CatEntity } from './cat.entity';
export declare class CatHomeEntity {
    id: number;
    name: string;
    street: string | null;
    cat: CatEntity;
    pillows: CatHomePillowEntity[];
    naptimePillow: CatHomePillowEntity | null;
    createdAt: string;
    config: Record<string, any> | null;
    countCat: number;
}
