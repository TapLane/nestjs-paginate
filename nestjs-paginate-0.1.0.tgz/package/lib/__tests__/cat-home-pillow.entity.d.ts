import { CatHomePillowBrandEntity } from './cat-home-pillow-brand.entity';
import { CatHomeEntity } from './cat-home.entity';
export declare class CatHomePillowEntity {
    id: number;
    home: CatHomeEntity;
    color: string;
    brand: CatHomePillowBrandEntity;
    createdAt: string;
}
