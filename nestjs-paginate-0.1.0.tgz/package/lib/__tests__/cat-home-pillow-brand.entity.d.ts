export declare class CatHomePillowBrandEntity {
    id: number;
    name: string;
    quality: string;
}
