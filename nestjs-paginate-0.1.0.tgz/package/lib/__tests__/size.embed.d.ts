export declare class SizeEmbed {
    height: number;
    width: number;
    length: number;
}
