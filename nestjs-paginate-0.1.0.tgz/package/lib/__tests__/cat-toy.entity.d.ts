import { CatEntity } from './cat.entity';
import { SizeEmbed } from './size.embed';
import { ToyShopEntity } from './toy-shop.entity';
export declare class CatToyEntity {
    id: number;
    name: string;
    size: SizeEmbed;
    shop?: ToyShopEntity;
    cat: CatEntity;
    createdAt: string;
}
