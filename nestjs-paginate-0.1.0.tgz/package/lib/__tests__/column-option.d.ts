import { ColumnOptions } from 'typeorm';
export declare const DateColumnNotNull: ColumnOptions;
export declare const DateColumnNullable: ColumnOptions;
