export declare class ToyShopAddressEntity {
    id: number;
    address: string;
    createdAt: string;
}
