import { CatHomeEntity } from './cat-home.entity';
import { CatToyEntity } from './cat-toy.entity';
import { SizeEmbed } from './size.embed';
export declare enum CutenessLevel {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high"
}
export declare class CatEntity {
    id: number;
    name: string;
    color: string;
    age: number | null;
    cutenessLevel: CutenessLevel;
    lastVetVisit: Date | null;
    size: SizeEmbed;
    toys: CatToyEntity[];
    home: CatHomeEntity;
    createdAt: string;
    deletedAt?: string;
    friends: CatEntity[];
    weightChange: number | null;
    private afterLoad;
}
