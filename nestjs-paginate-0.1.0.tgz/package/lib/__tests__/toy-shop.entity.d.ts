import { ToyShopAddressEntity } from './toy-shop-address.entity';
export declare class ToyShopEntity {
    id: number;
    shopName: string;
    address: ToyShopAddressEntity;
    createdAt: string;
}
