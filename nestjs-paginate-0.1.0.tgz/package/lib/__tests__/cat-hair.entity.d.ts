export declare class CatHairEntity {
    id: number;
    name: string;
    colors: string[];
    createdAt: string;
    metadata: Record<string, any>;
    underCoat: CatHairEntity;
}
