import { FindOperator, SelectQueryBuilder } from 'typeorm';
import { WherePredicateOperator } from 'typeorm/query-builder/WhereClause';
import { PaginateQuery } from './decorator';
import { JoinMethod } from './helper';
export declare enum FilterOperator {
    EQ = "$eq",
    GT = "$gt",
    GTE = "$gte",
    IN = "$in",
    NULL = "$null",
    LT = "$lt",
    LTE = "$lte",
    BTW = "$btw",
    ILIKE = "$ilike",
    SW = "$sw",
    CONTAINS = "$contains"
}
export declare function isOperator(value: unknown): value is FilterOperator;
export declare enum FilterSuffix {
    NOT = "$not"
}
export declare function isSuffix(value: unknown): value is FilterSuffix;
export declare enum FilterComparator {
    AND = "$and",
    OR = "$or"
}
export declare function isComparator(value: unknown): value is FilterComparator;
export declare const OperatorSymbolToFunction: Map<FilterOperator | FilterSuffix, (...args: any[]) => FindOperator<string>>;
type Filter = {
    comparator: FilterComparator;
    findOperator: FindOperator<string>;
};
type ColumnFilters = {
    [columnName: string]: Filter[];
};
type ColumnJoinMethods = {
    [columnName: string]: JoinMethod;
};
export interface FilterToken {
    comparator: FilterComparator;
    suffix?: FilterSuffix;
    operator: FilterOperator;
    value: string;
}
export declare function fixQueryParam(alias: string, column: string, filter: Filter, condition: WherePredicateOperator, parameters: {
    [key: string]: string;
}): {
    [key: string]: string;
};
export declare function generatePredicateCondition(qb: SelectQueryBuilder<unknown>, column: string, filter: Filter, alias: string, isVirtualProperty?: boolean): WherePredicateOperator;
export declare function addWhereCondition<T>(qb: SelectQueryBuilder<T>, column: string, filter: ColumnFilters): void;
export declare function parseFilterToken(raw?: string): FilterToken | null;
export declare function parseFilter<T>(query: PaginateQuery, filterableColumns?: {
    [column: string]: (FilterOperator | FilterSuffix)[] | true;
}, qb?: SelectQueryBuilder<T>): ColumnFilters;
export declare function addFilter<T>(qb: SelectQueryBuilder<T>, query: PaginateQuery, filterableColumns?: {
    [column: string]: (FilterOperator | FilterSuffix)[] | true;
}): ColumnJoinMethods;
export {};
